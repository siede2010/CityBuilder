let rain
function effects()
{
    rain = new RainType("./img/weather/rain.png","./img/weather/rainFall",3,15)
}